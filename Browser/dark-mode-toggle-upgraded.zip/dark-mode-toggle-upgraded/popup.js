let darkModeEnabled = false;

document.getElementById('toggleBtn').addEventListener('click', async () => { 
 const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  // Send message to background to toggle
  chrome.runtime.sendMessage(
    { action: 'toggleDarkMode', tabId: tab.id },
    (response) => {
      if (response?.success) {
        darkModeEnabled = response.isDark;
        document.getElementById('status').textContent =
          darkModeEnabled ? '💁 Dark Mode: ON' : '⚡️  Dark Mode: OFF';
        document.getElementById('toggleBtn').textContent =
          darkModeEnabled ? '⨇< Switch to Light' : '👀 Switch to Dark';
      } else {
        document.getElementById('status').textContent = '⌁ error occurred';
      }
    }
  );
});
