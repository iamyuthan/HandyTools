// Track dark mode state per tab
const tabStates = {};

// FIX: Guard against restricted URLs that cannot be scripted
// (chrome://, chrome-extension://extensions gallery, etc.)
function isRestrictedUrl(url) {
  if (!url) return true;
  return (
    url.startsWith('chrome://') ||
    url.startsWith('chrome-extension://') ||
    url.startsWith('https://chrome.google.com/webstore') ||
    url.startsWith('about:') ||
    url.startsWith('edge://')
  );
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle toggling dark mode
  if (message.action === 'toggleDarkMode') {
    const tabId = message.tabId || sender.tab?.id;
    if (!tabId) {
      console.error("Background Error: Could not determine tab ID");
      sendResponse({ success: false });
      return true;
    }

    // FIX: Check the tab's URL before attempting to attach debugger
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab || isRestrictedUrl(tab.url)) {
        console.warn(`Skipping restricted/unknown tab: ${tab?.url}`);
        sendResponse({ success: false });
        return;
      }

      const currentState = tabStates[tabId] && tabStates[tabId].isDark;
      const newState = !currentState;
      setDarkMode(tabId, newState, sendResponse);
    });

    return true; // Keep message channel open for async
  }

  // Handle getting current state
  if (message.action === 'getState') {
    const tabId = sender.tab?.id;
    if (tabId && tabStates[tabId]) {
      sendResponse({ isDark: tabStates[tabId].isDark });
    } else {
      sendResponse({ isDark: false });
    }
    return true;
  }
});

function setDarkMode(tabId, enable, sendResponse) {
  // Smartly attach or send command to avoid errors
  if (!tabStates[tabId] || !tabStates[tabId].isAttached) {
    chrome.debugger.attach({ tabId }, "1.3", () => {
      if (shouldDetachOnError(tabId)) {
        sendResponse({ success: false });
        return;
      }
      tabStates[tabId] = { ...tabStates[tabId], isAttached: true };
      sendCommand(tabId, enable, sendResponse);
    });
  } else {
    sendCommand(tabId, enable, sendResponse);
  }
}

function sendCommand(tabId, enable, sendResponse) {
  const method = 'Emulation.setAutoDarkModeOverride';
  chrome.debugger.sendCommand({ tabId }, method, { enabled: enable }, () => {
    if (shouldDetachOnError(tabId)) {
      sendResponse({ success: false });
      return;
    }
    tabStates[tabId] = { ...tabStates[tabId], isDark: enable };
    sendResponse({ success: true, isDark: enable });
  });
}

function shouldDetachOnError(tabId) {
  if (chrome.runtime.lastError) {
    console.error(`Command Error: ${chrome.runtime.lastError.message}`);
    deattachDebugger(tabId);
    return true;
  }
  return false;
}

function deattachDebugger(tabId) {
  if (tabId && tabStates[tabId]?.isAttached) {
    // Tab may already be gone — ignore any errors from detach
    chrome.debugger.detach({ tabId }, () => void chrome.runtime.lastError);
  }
  delete tabStates[tabId];
}

// Clean up reliably
chrome.tabs.onRemoved.addListener(deattachDebugger);
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    deattachDebugger(tabId);
  }
});
