// This file creates the floating button on the page.

(async () => {
  // 1. Create the button
  const toggleBtn = document.createElement('div');
  toggleBtn.id = 'dark-mode-toggler-floating-button';
  document.body.appendChild(toggleBtn);

  // 2. Apply base styles inline — inline styles are NOT affected by
  //    Emulation.setAutoDarkModeOverride, so background colors stay correct.
  Object.assign(toggleBtn.style, {
    position: 'fixed',
    bottom: '30px',
    right: '30px',
    width: '50px',
    height: '50px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '24px',
    cursor: 'pointer',
    zIndex: '99999999',
    transition: 'background-color 0.3s ease, box-shadow 0.3s ease',
    colorScheme: 'light',  // prevent the element itself from being dark-mode-inverted
    // default dark bg until state loads
    backgroundColor: '#2C2C2C',
    boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
  });

  // 3. Add click handler
  toggleBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    // FIX: was "respoonse" (typo) — renamed to "response"
    chrome.runtime.sendMessage({ action: 'toggleDarkMode' }, (response) => {
      if (response?.success) {
        updateIcon(response.isDark);
      }
    });
  });

  // 4. Function to update the icon — inline styles survive dark mode inversion
  function updateIcon(isDarkState) {
    toggleBtn.textContent = isDarkState ? '☀️' : '🌙';
    toggleBtn.style.backgroundColor = isDarkState ? '#FFFFFF' : '#2C2C2C';
    toggleBtn.style.boxShadow = isDarkState
      ? '0 4px 12px rgba(0,0,0,0.5)'
      : '0 4px 12px rgba(0,0,0,0.4)';
  }

  // 5. Get current state on page load
  chrome.runtime.sendMessage({ action: 'getState' }, (response) => {
    if (response) {
      updateIcon(response.isDark);
    }
  });
})();
